import 'package:flutter/material.dart';
import 'package:flutter_demo_blocs/flutter_bloc_ex/posts/view/posts_page.dart';

class App extends MaterialApp {
  App() : super(home: PostsPage());
}