package com.flutter_demo_blocs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
